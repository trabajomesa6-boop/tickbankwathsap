# TickBank Chatbot Full Package (WhatsApp + Admin)

Este paquete contiene un prototipo listo para personalizar y desplegar. Incluye:
- Webhook server para Callbell (WhatsApp)
- Worker (BullMQ) para procesamiento de flujos, cursos y tickets
- Flows: tickets, cursos, mini-quizzes, calendar events, accessibility & legal templates
- Stripe payments stub (serverside)
- SQL schema para Postgres
- AdminPanel React component (src/AdminPanel.jsx)
- Dockerfile + Procfile

## Pasos rápidos para ejecutar localmente
1. Copia `.env.example` a `.env` y define: DATABASE_URL, REDIS_URL, OPENAI_API_KEY, CALLBELL_API_KEY, CALLBELL_ACCOUNT_ID
2. `npm install`
3. Ejecuta migraciones: `psql $DATABASE_URL -f sql/schema.sql`
4. `npm run dev` (o en producción `npm start` y `node queue.js` para el worker)
5. Exponer con ngrok para pruebas: `ngrok http 3000` y configurar webhook en Callbell hacia `https://<ngrok>/webhook/callbell`

## Personalización
- Reemplaza `data/lessons.json` y `data/events.json` con tus módulos y calendario reales.
- Ajusta `flows/courseFlow.js` para integrar con la tabla `lessons` y `quizzes` en la DB.
- Implementa `services/payments.js` con Stripe SDK para recibir pagos reales.

## Admin Panel
- Copia `src/AdminPanel.jsx` en tu app React + Tailwind y ajusta `REACT_APP_API_BASE`

## Seguridad
- No guardes claves en repositorios públicos.
- Regenera claves si se exponen.
