-- SQL schema for TickBank chatbot
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone TEXT UNIQUE,
  name TEXT,
  state JSONB DEFAULT '{}' ,
  language VARCHAR(10) DEFAULT 'es',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  direction VARCHAR(10),
  channel VARCHAR(20),
  payload JSONB,
  text TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE tickets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  subject TEXT,
  message TEXT,
  status VARCHAR(20) DEFAULT 'open',
  priority VARCHAR(10) DEFAULT 'normal',
  assigned_to TEXT,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);

CREATE TABLE courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT, slug TEXT UNIQUE, description TEXT, price_cents INTEGER DEFAULT 0, currency TEXT DEFAULT 'USD', created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID REFERENCES courses(id),
  title TEXT, content TEXT, position INT, duration_seconds INT, created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE enrollments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  course_id UUID REFERENCES courses(id),
  status TEXT DEFAULT 'active', joined_at TIMESTAMP DEFAULT now()
);

CREATE TABLE class_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID REFERENCES courses(id),
  title TEXT, start_at TIMESTAMP, end_at TIMESTAMP, timezone TEXT, created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE quizzes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id UUID REFERENCES lessons(id),
  question TEXT, choices JSONB, correct_index INT
);

CREATE TABLE quiz_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  quiz_id UUID REFERENCES quizzes(id),
  answer_index INT, correct BOOLEAN, attempted_at TIMESTAMP DEFAULT now()
);
