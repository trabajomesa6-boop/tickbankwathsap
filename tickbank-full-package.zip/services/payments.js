// payments.js - Stripe stub (server-side). Replace with your stripe keys and expand.
import dotenv from 'dotenv';
dotenv.config();

export async function createCheckoutSession(course) {
  // Placeholder: in production use stripe SDK
  return { url: 'https://checkout.example.com/session-placeholder' };
}
