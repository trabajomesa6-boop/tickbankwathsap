// queue.js - BullMQ worker (processes messages, course flows, tickets, reminders)
import { Queue, Worker } from 'bullmq';
import IORedis from 'ioredis';
import dotenv from 'dotenv';
dotenv.config();
import { askOpenAI } from './openai.js';
import { sendTextToWhatsApp } from './callbell.js';
import { query } from './db.js';
import { getCourseStep } from './flows/courseFlow.js';

const connection = new IORedis(process.env.REDIS_URL);
export const messageQueue = new Queue('messages', { connection });

// worker
new Worker('messages', async (job) => {
  const { userId, phone, text, userState, channel } = job.data;
  console.log('Processing job', job.id, 'channel', channel);

  try {
    // Course mode handling
    if (userState && userState.mode === 'course') {
      const stepData = await getCourseStep(userState, text);
      await query('UPDATE users SET state=$1 WHERE id=$2', [JSON.stringify({ step: stepData.nextStep, mode: 'course' }), userId]);
      await sendTextToWhatsApp(phone, stepData.text);
      return;
    }

    // Tickets: if user sent "soporte" start a ticket flow
    if (text && text.toLowerCase().includes('soporte')) {
      // create a simple ticket
      const subject = 'Soporte - consulta desde WhatsApp';
      const ins = await query('INSERT INTO tickets(user_id, subject, message) VALUES($1,$2,$3) RETURNING id', [userId, subject, text]);
      const ticketId = ins.rows[0].id;
      await sendTextToWhatsApp(phone, `🎫 Ticket creado: #${ticketId}\nUn agente te responderá pronto.`);
      return;
    }

    // default: ask OpenAI for a reply (if configured)
    let answer = 'Lo siento, no puedo procesar tu solicitud en este momento.';
    if (process.env.OPENAI_API_KEY) {
      answer = await askOpenAI(userId, [], text);
    }
    await query('INSERT INTO messages(user_id, direction, channel, text) VALUES($1,$2,$3,$4)', [userId, 'out', 'whatsapp', answer]);
    await sendTextToWhatsApp(phone, answer);
  } catch (err) {
    console.error('Worker error', err);
    await sendTextToWhatsApp(phone, 'Lo siento, ha ocurrido un error. Un agente humano te contactará.');
  }
}, { connection });
