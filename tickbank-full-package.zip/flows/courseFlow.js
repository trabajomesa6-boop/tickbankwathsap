// courseFlow.js - supports courses, lessons, quizzes and reminders
import fs from 'fs';
import path from 'path';

// load simple JSON files for demo lessons and events (replace with DB in prod)
const lessonsFile = path.join(process.cwd(), 'data', 'lessons.json');
const eventsFile = path.join(process.cwd(), 'data', 'events.json');

const sampleLessons = fs.existsSync(lessonsFile) ? JSON.parse(fs.readFileSync(lessonsFile,'utf8')) : [];
const sampleEvents = fs.existsSync(eventsFile) ? JSON.parse(fs.readFileSync(eventsFile,'utf8')) : [];

export async function getCourseStep(userState, userMessage) {
  const lower = String(userMessage||'').toLowerCase();
  if (!userState || !userState.step) {
    return {
      text: "👋 Bienvenido a TickBank Academy. ¿Deseas comenzar con la Lección 1? Responde 'Sí' o 'No'.\nAviso: este contenido es educativo y no constituye asesoramiento financiero.",
      options: ['Sí','No'],
      nextStep: 'intro'
    };
  }

  if (userState.step === 'intro') {
    if (lower.includes('sí') || lower.includes('si')) {
      const lesson = sampleLessons[0] || { title:'Lección 1', content:'Contenido de ejemplo' };
      return {
        text: `🧩 Lección 1: ${lesson.title}\n\n${lesson.content}\n\n¿Quieres el mini-quiz?`,
        options: ['Quiz','Siguiente'],
        nextStep: 'lesson1'
      };
    } else {
      return { text: 'Perfecto. Cuando quieras, escribe "curso" para comenzar.', options: [], nextStep: null };
    }
  }

  if (userState.step === 'lesson1') {
    if (lower.includes('quiz')) {
      // sample quiz from lessons
      const quiz = (sampleLessons[0] && sampleLessons[0].quiz) || null;
      if (quiz) {
        let qText = `Pregunta: ${quiz.question}\n`;
        quiz.choices.forEach((c,i)=> qText += `${i+1}) ${c}\n`);
        return { text: qText, options: quiz.choices, nextStep: 'lesson1_quiz' };
      }
      return { text: 'No hay quiz disponible.', options: [], nextStep: 'lesson2' };
    } else {
      return { text: 'Avanzando a la siguiente lección...', options: [], nextStep: 'lesson2' };
    }
  }

  if (userState.step === 'lesson1_quiz') {
    // naive answer handling: accept number or text
    const quiz = (sampleLessons[0] && sampleLessons[0].quiz) || null;
    const selected = Number(userMessage.trim()) - 1;
    const correct = quiz && selected === quiz.correct_index;
    return { text: correct ? '✅ Correcto' : '❌ Incorrecto', options: [], nextStep: 'lesson2' };
  }

  return { text: 'Has completado el módulo básico. ¿Deseas otra cosa?', options: [], nextStep: null };
}
