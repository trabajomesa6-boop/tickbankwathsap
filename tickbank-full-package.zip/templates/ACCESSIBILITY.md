# Accesibilidad
Si necesitas materiales en formato alternativo (texto grande, audio, subtítulos), responde 'accesibilidad' y te entregaremos la versión adaptada.
