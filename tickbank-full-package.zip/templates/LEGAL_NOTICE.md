# Aviso de riesgo — TickBank Academy (ejemplo)
El contenido de nuestros cursos es estrictamente educativo. No constituye asesoramiento financiero, ni recomendamos operar sin la debida diligencia. Operar conlleva riesgos; puedes perder parte o todo tu capital.
