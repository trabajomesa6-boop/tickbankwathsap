// AdminPanel React component (single-file, same as previously created)
import React, { useEffect, useState } from 'react';

const API_BASE = process.env.REACT_APP_API_BASE || '';

function authHeaders() {
  const token = localStorage.getItem('admin_token') || '';
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export default function AdminPanel() {
  const [tickets, setTickets] = useState([]);
  const [courses, setCourses] = useState([]);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [ticketReplies, setTicketReplies] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showCourseModal, setShowCourseModal] = useState(false);
  const [showTicketModal, setShowTicketModal] = useState(false);
  const [newCourse, setNewCourse] = useState({ title:'', slug:'', description:'', price_cents:0 });
  const [announceMsg, setAnnounceMsg] = useState('');

  useEffect(() => {
    fetchTickets();
    fetchCourses();
  }, []);

  async function fetchTickets() {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/tickets`, { headers: { 'Content-Type':'application/json', ...authHeaders() } });
      const data = await res.json();
      setTickets(data || []);
    } catch(e) { console.error(e); }
    setLoading(false);
  }

  async function fetchCourses() {
    try {
      const res = await fetch(`${API_BASE}/api/courses`, { headers: { 'Content-Type':'application/json', ...authHeaders() } });
      const data = await res.json();
      setCourses(data || []);
    } catch(e) { console.error(e); }
  }

  async function openTicket(id) {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/tickets/${id}`, { headers: { 'Content-Type':'application/json', ...authHeaders() } });
      const data = await res.json();
      setSelectedTicket(data);
      setTicketReplies(data.replies || []);
      setShowTicketModal(true);
    } catch(e) { console.error(e); }
    setLoading(false);
  }

  async function replyToTicket(message) {
    if (!selectedTicket) return;
    try {
      const res = await fetch(`${API_BASE}/api/tickets/${selectedTicket.id}/reply`, {
        method: 'POST',
        headers: { 'Content-Type':'application/json', ...authHeaders() },
        body: JSON.stringify({ message })
      });
      const data = await res.json();
      setTicketReplies(prev => [...prev, { id: data.id || Date.now(), from: 'admin', text: message, created_at: new Date().toISOString() }]);
    } catch(e) { console.error(e); }
  }

  async function createCourse() {
    try {
      const res = await fetch(`${API_BASE}/api/courses`, {
        method: 'POST', headers: { 'Content-Type':'application/json', ...authHeaders() },
        body: JSON.stringify(newCourse)
      });
      const created = await res.json();
      setCourses(prev => [created, ...prev]);
      setShowCourseModal(false);
      setNewCourse({ title:'', slug:'', description:'', price_cents:0 });
    } catch(e) { console.error(e); }
  }

  async function sendAnnouncement(courseId=null) {
    try {
      const res = await fetch(`${API_BASE}/api/admin/announce`, {
        method: 'POST', headers: { 'Content-Type':'application/json', ...authHeaders() },
        body: JSON.stringify({ courseId, message: announceMsg })
      });
      const data = await res.json();
      alert('Anuncio enviado');
      setAnnounceMsg('');
    } catch(e) { console.error(e); alert('Error enviando anuncio'); }
  }

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-6">
      <div className="max-w-7xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-semibold">TickBank — Admin Panel</h1>
          <div className="flex items-center gap-4">
            <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={()=>{ setShowCourseModal(true); }}>Nuevo Curso</button>
            <button className="px-3 py-1 bg-emerald-600 text-white rounded" onClick={()=>fetchTickets()}>Refrescar</button>
          </div>
        </header>

        <div className="grid grid-cols-3 gap-6">
          <div className="col-span-2 bg-white p-4 rounded shadow">
            <h2 className="font-medium mb-3">Tickets de soporte</h2>
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-xs text-slate-500">
                  <th className="py-2">ID</th>
                  <th>Usuario</th>
                  <th>Asunto</th>
                  <th>Estado</th>
                  <th>Creado</th>
                </tr>
              </thead>
              <tbody>
                {tickets.length===0 && <tr><td colSpan="5" className="py-4 text-center text-slate-400">No hay tickets</td></tr>}
                {tickets.map(t => (
                  <tr key={t.id} className="border-t hover:bg-slate-50">
                    <td className="py-3">{t.id.split('-')[0]}</td>
                    <td>{t.user_name || t.user_phone || '—'}</td>
                    <td>{t.subject}</td>
                    <td className={`capitalize ${t.status==='open' ? 'text-amber-600' : t.status==='closed' ? 'text-slate-400' : 'text-sky-600'}`}>{t.status}</td>
                    <td>{new Date(t.created_at).toLocaleString()}</td>
                    <td>
                      <button className="ml-2 px-2 py-1 bg-sky-600 text-white rounded" onClick={()=>openTicket(t.id)}>Abrir</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h3 className="font-medium mb-3">Cursos</h3>
            <div className="space-y-3 max-h-[400px] overflow-auto">
              {courses.map(c => (
                <div key={c.id} className="p-3 border rounded flex justify-between items-center">
                  <div>
                    <div className="font-semibold">{c.title}</div>
                    <div className="text-xs text-slate-500">{c.slug} • {c.price_cents/100} {c.currency||'USD'}</div>
                  </div>
                  <div className="flex gap-2">
                    <button className="px-2 py-1 text-sm bg-slate-200 rounded" onClick={()=>navigator.clipboard.writeText(`${API_BASE}/courses/${c.slug}`)}>Copiar link</button>
                    <button className="px-2 py-1 text-sm bg-slate-100 rounded" onClick={()=>alert('Abrir editor de lecciones (no implementado en demo)')}>Editar</button>
                  </div>
                </div>
              ))}
              {courses.length===0 && <div className="text-slate-400">Sin cursos</div>}
            </div>

            <div className="mt-6">
              <h4 className="font-medium">Enviar anuncio</h4>
              <textarea value={announceMsg} onChange={(e)=>setAnnounceMsg(e.target.value)} placeholder="Mensaje para inscritos..." className="w-full border p-2 rounded mt-2"></textarea>
              <div className="flex gap-2 mt-2">
                <button className="px-3 py-1 bg-indigo-600 text-white rounded" onClick={()=>sendAnnouncement(null)}>Enviar a todos</button>
                <button className="px-3 py-1 bg-slate-200 rounded" onClick={()=>sendAnnouncement(courses[0]?.id)}>Enviar al primer curso</button>
              </div>
            </div>
          </div>
        </div>

        {showCourseModal && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
            <div className="bg-white w-[640px] rounded p-6">
              <h3 className="font-semibold mb-3">Crear nuevo curso</h3>
              <div className="grid grid-cols-2 gap-3">
                <input placeholder="Título" value={newCourse.title} onChange={(e)=>setNewCourse({...newCourse, title:e.target.value})} className="border p-2 rounded" />
                <input placeholder="Slug" value={newCourse.slug} onChange={(e)=>setNewCourse({...newCourse, slug:e.target.value})} className="border p-2 rounded" />
                <textarea placeholder="Descripción" value={newCourse.description} onChange={(e)=>setNewCourse({...newCourse, description:e.target.value})} className="border p-2 rounded col-span-2"></textarea>
                <input type="number" placeholder="Precio (cents)" value={newCourse.price_cents} onChange={(e)=>setNewCourse({...newCourse, price_cents: parseInt(e.target.value||0)})} className="border p-2 rounded" />
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <button className="px-3 py-1 bg-slate-200 rounded" onClick={()=>setShowCourseModal(false)}>Cancelar</button>
                <button className="px-3 py-1 bg-emerald-600 text-white rounded" onClick={createCourse}>Crear</button>
              </div>
            </div>
          </div>
        )}

        {showTicketModal && selectedTicket && (
          <div className="fixed inset-0 bg-black/40 flex items-center justify-center">
            <div className="bg-white w-[800px] rounded p-6">
              <h3 className="font-semibold">Ticket #{selectedTicket.id}</h3>
              <div className="text-sm text-slate-600 mb-4">{selectedTicket.subject} • {new Date(selectedTicket.created_at).toLocaleString()}</div>
              <div className="grid grid-cols-2 gap-4">
                <div className="border p-3 rounded h-72 overflow-auto">
                  <div className="font-medium mb-2">Conversación</div>
                  {ticketReplies.map(r => (
                    <div key={r.id} className={`mb-2 ${r.from==='admin' ? 'text-right' : 'text-left'}`}>
                      <div className={`inline-block p-2 rounded ${r.from==='admin' ? 'bg-emerald-100' : 'bg-slate-100'}`}>{r.text}</div>
                      <div className="text-xs text-slate-400">{new Date(r.created_at).toLocaleString()}</div>
                    </div>
                  ))}
                </div>
                <div>
                  <div className="mb-2 font-medium">Responder</div>
                  <ReplyForm onSend={replyToTicket} />
                  <div className="mt-4">
                    <label className="text-sm">Cambiar estado</label>
                    <select defaultValue={selectedTicket.status} className="block border p-2 rounded mt-1" onChange={async (e)=>{ const st = e.target.value; await fetch(`${API_BASE}/api/tickets/${selectedTicket.id}`, { method:'PUT', headers:{...authHeaders(),'Content-Type':'application/json'}, body:JSON.stringify({ status: st }) }); fetchTickets(); setShowTicketModal(false); }}>
                      <option value="open">open</option>
                      <option value="pending">pending</option>
                      <option value="closed">closed</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex justify-end mt-4">
                <button className="px-3 py-1 bg-slate-200 rounded" onClick={()=>setShowTicketModal(false)}>Cerrar</button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}

function ReplyForm({ onSend }) {
  const [text, setText] = useState('');
  return (
    <div>
      <textarea className="w-full border p-2 rounded" rows={6} value={text} onChange={(e)=>setText(e.target.value)} />
      <div className="flex justify-end gap-2 mt-2">
        <button className="px-3 py-1 bg-slate-200 rounded" onClick={()=>setText('')}>Limpiar</button>
        <button className="px-3 py-1 bg-blue-600 text-white rounded" onClick={()=>{ onSend(text); setText(''); }}>Enviar</button>
      </div>
    </div>
  );
}
