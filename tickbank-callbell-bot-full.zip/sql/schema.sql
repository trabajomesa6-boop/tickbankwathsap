-- Requires pgcrypto extension for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone VARCHAR(32) UNIQUE,
  name TEXT,
  state JSONB DEFAULT '{"mode":"default"}',
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  direction VARCHAR(10) NOT NULL, -- 'in' or 'out'
  channel VARCHAR(32), -- 'whatsapp'
  payload JSONB,
  text TEXT,
  created_at TIMESTAMP DEFAULT now()
);
