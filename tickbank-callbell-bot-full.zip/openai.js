// openai.js
import axios from 'axios';
import dotenv from 'dotenv';
dotenv.config();

const OPENAI_KEY = process.env.OPENAI_API_KEY;

export async function askOpenAI(userId, conversationHistory, userMessage) {
  const prompt = [
    { role: "system", content: "Eres TB-Guide, asistente experto de TickBank. Respondes en español neutro, de forma clara y profesional." },
    ...conversationHistory,
    { role: "user", content: userMessage }
  ];

  const resp = await axios.post('https://api.openai.com/v1/chat/completions', {
    model: "gpt-4o-mini",
    messages: prompt,
    max_tokens: 500,
    temperature: 0.2
  }, {
    headers: { Authorization: `Bearer ${OPENAI_KEY}` }
  });

  return resp.data.choices[0].message.content;
}
