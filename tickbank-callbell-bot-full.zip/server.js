// server.js - enhanced with queue and webhook signature stub
import express from 'express';
import bodyParser from 'body-parser';
import dotenv from 'dotenv';
dotenv.config();

import { query } from './db.js';
import { messageQueue } from './queue.js';
import { normalizePhone } from './flows/utils.js';

const app = express();
app.use(bodyParser.json());

// Basic webhook signature validation (stub - adapt to Callbell if they provide HMAC)
function validateWebhook(req) {
  const secret = process.env.WEBHOOK_SECRET;
  if (!secret) return true; // no validation in dev
  // Implement HMAC or signature checking here if Callbell provides it
  return true;
}

app.post('/webhook/callbell', async (req, res) => {
  try {
    if (!validateWebhook(req)) return res.status(401).send({ ok: false, error: 'invalid signature' });

    const event = req.body;
    const msg = event.data || event;
    const rawFrom = msg.from || (msg.sender && msg.sender.phone) || msg.phone;
    const text = msg.text || (msg.content && msg.content.text) || '';

    const from = normalizePhone(String(rawFrom || ''));
    if (!from) return res.status(400).send({ ok: false, error: 'no sender phone' });

    // Find or create user
    const userRes = await query('SELECT id, state FROM users WHERE phone=$1', [from]);
    let userId, userState = { mode: 'default' };
    if (userRes.rows.length === 0) {
      const insertU = await query('INSERT INTO users(phone, state) VALUES($1,$2) RETURNING id', [from, JSON.stringify(userState)]);
      userId = insertU.rows[0].id;
    } else {
      userId = userRes.rows[0].id;
      try { userState = JSON.parse(userRes.rows[0].state) } catch(e){ userState = { mode: 'default' } }
    }

    // Store incoming message
    await query('INSERT INTO messages(user_id, direction, channel, payload, text) VALUES($1,$2,$3,$4,$5)', [
      userId, 'in', 'whatsapp', msg, text
    ]);

    // If message triggers course mode
    if (text && text.toLowerCase().includes('curso')) {
      userState = { mode: 'course', step: null };
      await query('UPDATE users SET state=$1 WHERE id=$2', [JSON.stringify(userState), userId]);
    }

    // Enqueue job for processing
    await messageQueue.add('process', { userId, phone: from, text, userState });

    res.status(200).send({ ok: true });
  } catch (err) {
    console.error('Webhook error', err);
    res.status(500).send({ ok: false, error: String(err) });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server listening on ${port}`));
