// flows/courseFlow.js
export async function getCourseStep(userState, userMessage) {
  const lower = String(userMessage || '').toLowerCase();

  if (!userState || !userState.step) {
    return {
      text: "👋 ¡Bienvenido al curso TickBank! ¿Deseas comenzar con la Lección 1? Responde: 'Sí' o 'No'.",
      options: ["Sí", "No"],
      nextStep: "intro"
    };
  }

  if (userState.step === "intro") {
    if (lower.includes("sí") || lower.includes("si")) {
      return {
        text: "🧩 Lección 1: ¿Qué es el bot de trading TickBank? TickBank automatiza coberturas para proteger inversión. ¿Quieres que muestre un ejemplo práctico?",
        options: ["Sí, ejemplo", "No, siguiente"],
        nextStep: "lesson1"
      };
    } else {
      return { text: "Perfecto. Cuando quieras, escribe 'curso' para comenzar.", options: [], nextStep: null };
    }
  }

  if (userState.step === "lesson1") {
    if (lower.includes("sí") || lower.includes("si") || lower.includes("ejemplo")) {
      return {
        text: "Ejemplo práctico: Supongamos una posición long en BTC. El bot abre una posición corta parcial para cubrir la caída potencial. ¿Quieres probar una simulación?",
        options: ["Sí, simular", "No, siguiente"],
        nextStep: "lesson1_sim"
      };
    } else {
      return { text: "Avanzando a la siguiente lección...", options: [], nextStep: "lesson2" };
    }
  }

  if (userState.step === "lesson1_sim") {
    return { text: "La simulación está en desarrollo. Te avisaremos cuando esté lista.", options: [], nextStep: "lesson2" };
  }

  return { text: "Has completado el curso básico. ¿Deseas un certificado?", options: ["Sí", "No"], nextStep: "complete" };
}
