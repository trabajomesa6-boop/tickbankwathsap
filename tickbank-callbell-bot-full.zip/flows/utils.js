// flows/utils.js
export function normalizePhone(phone) {
  // simple normalization (improve as needed)
  return phone.replace(/[^0-9+]/g, '');
}
