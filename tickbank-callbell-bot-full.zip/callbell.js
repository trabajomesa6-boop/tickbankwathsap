// callbell.js
import axios from 'axios';
import dotenv from 'dotenv';
dotenv.config();

const CALLBELL_API_BASE = process.env.CALLBELL_API_BASE || 'https://api.callbell.eu/v1';
const CALLBELL_API_KEY = process.env.CALLBELL_API_KEY;
const ACCOUNT_ID = process.env.CALLBELL_ACCOUNT_ID;

export async function sendTextToWhatsApp(toNumber, text, metadata = {}) {
  const url = `${CALLBELL_API_BASE}/messages/send`;
  const payload = {
    account_id: ACCOUNT_ID,
    to: toNumber,
    channel: "whatsapp",
    type: "text",
    content: { text },
    metadata
  };

  const resp = await axios.post(url, payload, {
    headers: { Authorization: `Bearer ${CALLBELL_API_KEY}`, 'Content-Type': 'application/json' }
  });
  return resp.data;
}

export async function sendTemplate(toNumber, templateName, components=[]) {
  // Implement template sending per Callbell spec if needed
  const url = `${CALLBELL_API_BASE}/messages/send`;
  const payload = {
    account_id: ACCOUNT_ID,
    to: toNumber,
    channel: "whatsapp",
    type: "template",
    template: {
      name: templateName,
      language: "es",
      components
    }
  };
  const resp = await axios.post(url, payload, {
    headers: { Authorization: `Bearer ${CALLBELL_API_KEY}`, 'Content-Type': 'application/json' }
  });
  return resp.data;
}
