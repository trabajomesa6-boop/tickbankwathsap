# TickBank Callbell Chatbot - Full Starter Kit (Enhanced)

Esta versión incluye mejoras: cola (BullMQ + Redis), flujos de curso, validación de webhook (stub), y modularidad.

## Requisitos
- Node.js 18+
- PostgreSQL
- Redis (Upstash, Railway, Render, etc.)
- Cuenta Callbell con canal WhatsApp configurado
- API Key de OpenAI

## Pasos rápidos de instalación
1. Copia `.env.example` a `.env` y completa las variables.
2. Crea la base de datos y ejecuta `sql/schema.sql`.
3. Instala dependencias:
   ```bash
   npm install
   ```
4. Inicia Redis (o usa URL en REDIS_URL).
5. Ejecuta la app:
   ```bash
   npm run dev
   ```
6. Configura webhook en Callbell apuntando a:
   `https://TU_DOMINIO/webhook/callbell`

## Notas de seguridad
- Implementa validación HMAC si Callbell provee firmas.
- Añade rate-limiting y colas para evitar abusos.
- Requiere revisión antes de usar en producción.

## Deploy sugerido
- Render / Railway / Fly / Heroku para app Node.js
- Upstash para Redis gratuito
- Posgres en Railway / Supabase / AWS RDS

## Extensiones futuras
- Panel admin (React) para revisar chats y progreso
- Integración con Runway para generar assets desde prompts
- Soporte TTS y avatar 3D en la web
