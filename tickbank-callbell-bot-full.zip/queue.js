// queue.js
import { Queue, Worker } from 'bullmq';
import IORedis from 'ioredis';
import dotenv from 'dotenv';
dotenv.config();
import { askOpenAI } from './openai.js';
import { sendTextToWhatsApp } from './callbell.js';
import { query } from './db.js';
import { getCourseStep } from './flows/courseFlow.js';

const connection = new IORedis(process.env.REDIS_URL);
export const messageQueue = new Queue('messages', { connection });

// Worker
new Worker('messages', async (job) => {
  const { userId, phone, text, userState } = job.data;
  console.log('Processing job for', phone);

  try {
    // If user is in course mode
    if (userState && userState.mode === 'course') {
      const stepData = await getCourseStep(userState, text);
      // Update user state
      await query('UPDATE users SET state=$1 WHERE id=$2', [JSON.stringify({ step: stepData.nextStep, mode: 'course' }), userId]);
      await sendTextToWhatsApp(phone, stepData.text);
      return;
    }

    // Otherwise, general LLM answer
    const answer = await askOpenAI(userId, [], text);
    await query('INSERT INTO messages(user_id, direction, channel, text) VALUES($1,$2,$3,$4)', [userId, 'out', 'whatsapp', answer]);
    await sendTextToWhatsApp(phone, answer);
  } catch (err) {
    console.error('Worker error', err);
    // fallback message
    await sendTextToWhatsApp(phone, "Lo siento, ha ocurrido un error. Un agente humano te responderá en breve.");
  }
}, { connection });
